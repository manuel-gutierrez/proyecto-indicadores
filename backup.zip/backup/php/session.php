<?php
session_start();
// Storing Session
$user_check=$_SESSION['login_user'];
// SQL Query To Fetch Complete Information Of User
$ses_sql=mysql_query("SELECT * FROM usuarios WHERE email='$user_check'", $link);
$row = mysql_fetch_assoc($ses_sql);
$login_mail = $row['email'];
$login_fn = $row['first_name'];
$login_ln = $row['last_name'];
$login_usertype = $row['user_type'];
$login_occupation = $row['occupation'];
$login_pic = $row['pic'];
//if(!isset($login_session)){
//mysql_close($link); // Closing Connection
//header('Location: index.php'); // Redirecting To Home Page
//}
?>