<?php 
session_start();
// Starting Session
$error = '';
// Variable To Store Error Message
if (isset($_POST['submit'])) {
	if (empty($_POST['username']) || empty($_POST['password'])) {
		$error = "No ha ingresado el usuario y/o la contraseña";
	} else {
		// Define $username and $password
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		// To protect MySQL injection for Security purpose
		$username = stripslashes($username);
		$password = stripslashes($password);
		$username = mysql_real_escape_string($username);
		$password = mysql_real_escape_string($password);
		// SQL query to fetch information of registerd users and finds user match.
		$query = mysql_query("SELECT * FROM usuarios WHERE contrasena=SHA1('$password') AND email='$username'", $link);

		$rows = mysql_num_rows($query);
		if ($rows == 1) {
			$registro = mysql_fetch_object($query);
			$usertype = $registro->user_type;
			$_SESSION['login_user'] = $username;
			// Initializing Session
			if ($usertype==0) {
				header("location: ../inicio.php");
			} else {
				header("location: ../inicio1.php");
			}	
			// Redirecting To Other Page
		} else {
			$error = "El usuario y/o la contraseña son inválidos";
		}
		mysql_close($link);
		// Closing Connection*/
	} 
} 
?>